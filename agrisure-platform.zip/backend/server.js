const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.get('/weather', async (req, res) => {
  const location = req.query.location || 'Nairobi';
  const apiKey = 'YOUR_OPENWEATHERMAP_API_KEY';
  try {
    const weatherRes = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}`);
    const data = await weatherRes.json();
    const tempC = (data.main.temp - 273.15).toFixed(2);
    res.json({ temperature: tempC, weather: data.weather[0].description });
  } catch (error) {
    res.status(500).json({ error: 'Weather data fetch failed.' });
  }
});

app.get('/tips', (req, res) => {
  res.json({ tip: "Use certified drought-resistant seeds during dry seasons." });
});

app.post('/ussd', (req, res) => {
  const { text } = req.body;
  let response = "";

  if (text === "") {
    response = `CON Welcome to AgriSure\n1. Weather\n2. Tips`;
  } else if (text === "1") {
    response = `END Weather: Sunny, 28°C`;
  } else if (text === "2") {
    response = `END Tip: Plant early-maturing crops during dry forecasts.`;
  } else {
    response = `END Invalid choice.`;
  }

  res.set('Content-Type', 'text/plain');
  res.send(response);
});

app.listen(3000, () => console.log('Backend running on http://localhost:3000'));
