import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';

const App = () => {
  const [weather, setWeather] = useState(null);
  const [tip, setTip] = useState('Loading...');

  useEffect(() => {
    fetch('http://localhost:3000/weather?location=Kenya')
      .then(res => res.json())
      .then(data => setWeather(data));

    fetch('http://localhost:3000/tips')
      .then(res => res.json())
      .then(data => setTip(data.tip));
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>AgriSure</Text>
      <Text>Weather: {weather?.temperature}°C - {weather?.weather}</Text>
      <Text>Tip: {tip}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 20 },
  header: { fontSize: 24, fontWeight: 'bold' }
});

export default App;
