# AgriSure Climate-Smart Platform

## Backend Setup
1. Install Node.js
2. Navigate to `backend/` and run:
```
npm install express node-fetch cors
node server.js
```

## Frontend Setup
1. Use Expo or React Native CLI
2. Replace your `App.js` with the one in `frontend/`
3. Run with `expo start` or `npm start`

## USSD Simulation
Use Postman to `POST` to `http://localhost:3000/ussd` with JSON body:
```json
{ "text": "1" }
```

## Deployment
- Use [Render](https://render.com) for backend hosting
- Use Expo Go or Android Studio for mobile app
